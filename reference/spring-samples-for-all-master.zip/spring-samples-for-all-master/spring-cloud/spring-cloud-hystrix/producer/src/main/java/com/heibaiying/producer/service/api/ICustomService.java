package com.heibaiying.producer.service.api;

/**
 * @author : heibaiying
 * @description : 用户接口
 */
public interface ICustomService {

    String queryCustoms();

}
