package com.heibaiying.ymlprofile.config;

import lombok.Data;

/**
 * @author : heibaiying
 */
@Data
public class School {
    private String name;
    private String location;
}
