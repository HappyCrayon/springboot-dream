package com.heibaiying.ymlprofile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootYmlApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootYmlApplication.class, args);
    }

}

