package com.heibaiying.springboot.constant;

/**
 * @author : heibaiying
 * @description :
 */
public class Data {

    public static final String DATASOURCE1="DATASOURCE1";
    public static final String DATASOURCE2="DATASOURCE2";
}
