import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.heibaiying.bean.User;
import com.heibaiying.jackson.JacksonUtils;
import org.junit.Test;

import java.io.IOException;
import java.util.*;

/**
 * @author : heibaiying
 * @description : jackson 测试
 */
public class JacksonTests {

    @Test
    public void test() throws IOException {
        
    }
}
