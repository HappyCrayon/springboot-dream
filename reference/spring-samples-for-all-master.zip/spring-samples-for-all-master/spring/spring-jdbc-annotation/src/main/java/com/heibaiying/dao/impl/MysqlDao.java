package com.heibaiying.dao.impl;

import com.heibaiying.bean.Relation;
import java.util.List;

/**
 * @author : heibaiying
 * @description :
 */

public interface MysqlDao {

    List<Relation> get();
}
