package com.heibaiying.bean;

import lombok.Data;

/**
 * @author : heibaiying
 * @description :
 */
@Data
public class Relation {

    private String id;

    private String name;

}
