package com.heibaiying.bean;

import lombok.Data;

/**
 * @author : heibaiying
 * @description :
 */

@Data
public class Flow {

    private long id;

    private long flowId;

    private long plugId;
}
